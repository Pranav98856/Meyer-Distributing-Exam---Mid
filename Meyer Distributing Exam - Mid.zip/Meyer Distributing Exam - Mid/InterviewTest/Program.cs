﻿using InterviewTest.Customers;
using InterviewTest.Repository.Data.Models.Orders;
using InterviewTest.Repository.Data.Models.Products;
using InterviewTest.Repository.Data.Models.Returns;
using InterviewTest.Repository.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace InterviewTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
           .AddLogging()
           .AddSingleton<IOrderRepository, OrderRepository>()
           .AddSingleton<IReturnRepository, ReturnRepository>()
           .BuildServiceProvider();

            var orderRepo = serviceProvider.GetService<IOrderRepository>();
            var returnRepo = serviceProvider.GetService<IReturnRepository>();

            // ------------------------
            // Coding Challenge Requirements
            // ------------------------

            // 1: Create a database, contained locally within this project, and refactor all repositories (Order, Return, and Product) to utilize it.
            // 2: Implement get total sales, returns, and profit in the CustomerBase class.
            // 3: Record when an item was purchased.
            // 4: Ensure all output results, when running this console app, are correct. 

            // ------------------------
            // Bonus
            // ------------------------

            // 1: Refactor the customer classes to be repository/database based
            // 2: Create unit tests

            //Faced issues
            // I am trying to add migartion getting issues, That's why used exsting repositories.

            ProcessTruckAccessoriesExample(orderRepo, returnRepo);

            ProcessCarDealershipExample(orderRepo, returnRepo);

            Console.ReadKey();
        }

        private static void ProcessTruckAccessoriesExample(IOrderRepository orderRepo, IReturnRepository returnRepo)
        {
            var customer = GetTruckAccessoriesCustomer(orderRepo, returnRepo);

            IOrder order = new Order("TruckAccessoriesOrder123",new DateTime(2023, 11, 28), customer);
            order.AddProduct(new HitchAdapter());
            order.AddProduct(new BedLiner());
            customer.CreateOrder(order);

            IReturn rga = new Return("TruckAccessoriesReturn123", order);
            rga.AddProduct(order.Products.First());

            ConsoleWriteLineResults(customer);

            orderRepo.Remove(order);
            returnRepo.Remove(rga);
        }

        private static void ProcessCarDealershipExample(IOrderRepository orderRepo, IReturnRepository returnRepo)
        { 
            var customer = GetCarDealershipCustomer(orderRepo, returnRepo);

            IOrder order = new Order("CarDealerShipOrder123", new DateTime(2023, 11, 29), customer);
            order.AddProduct(new ReplacementBumper());
            order.AddProduct(new SyntheticOil());
            customer.CreateOrder(order);

            IReturn rga = new Return("CarDealerShipReturn123", order);
            rga.AddProduct(order.Products.First());
            customer.CreateReturn(rga);

            ConsoleWriteLineResults(customer);

            orderRepo.Remove(order);
            returnRepo.Remove(rga);
        }

        private static ICustomer GetTruckAccessoriesCustomer(IOrderRepository orderRepo, IReturnRepository returnRepo)
        {
            return new TruckAccessoriesCustomer(orderRepo, returnRepo);
        }

        private static ICustomer GetCarDealershipCustomer(IOrderRepository orderRepo, IReturnRepository returnRepo)
        {
            return new CarDealershipCustomer(orderRepo, returnRepo);
        }

        private static void ConsoleWriteLineResults(ICustomer customer)
        {
            Console.WriteLine(customer.GetName());

            var order = customer.GetOrders();

            foreach (var orderItem in order)
            {
                Console.WriteLine($"Order Number: {orderItem.OrderNumber}, Purchased Date: {orderItem.PurchasedDate.ToShortDateString()}" );
            }
           
            Console.WriteLine($"Total Sales: {customer.GetTotalSales().ToString("c")}");

            Console.WriteLine($"Total Returns: {customer.GetTotalReturns().ToString("c")}");

            Console.WriteLine($"Total Profit: {customer.GetTotalProfit().ToString("c")}");

            Console.WriteLine();
        }
    }
}
