﻿using InterviewTest.Repository.Data.Entity;
using InterviewTest.Repository.Data.EntityConfiguration;
using Microsoft.EntityFrameworkCore;
using System;

namespace InterviewTest.Repository
{
    public class InterviewTestContext : DbContext
    {
        public DbSet<Customer> Customer { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<OrderProducts> OrderProducts { get; set; }
        public DbSet<Products> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=InterviewTestDB;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new OrdersConfiguration());
            modelBuilder.ApplyConfiguration(new OrderProductsConfiguration());
            modelBuilder.ApplyConfiguration(new ProductsConfiguration());
            modelBuilder.Entity<Customer>().HasData(new Customer[] {
                 new Customer{CustomerId=Guid.Parse("0ca6074b-6d9b-4147-a906-762d3d925bff") ,Name="Ruxer Ford Lincoln, Inc."},
                 new Customer{CustomerId=Guid.Parse("6925cad6-0b0e-4e8f-83ae-3541102fa59b") ,Name="Meyer Truck Equipment"},
             });
            modelBuilder.Entity<Orders>().HasData(new Orders[] {
                 new Orders{OrderId=Guid.Parse("0d5bd54c-ebba-4a7d-ac1c-4a8e8b57c32d") ,OrderNumber="TruckAccessoriesOrder123"},
                 new Orders{OrderId=Guid.Parse("05202731-f5e2-4430-b0df-006f5df402ae") ,OrderNumber="TruckAccessoriesReturn123"},
             });
            modelBuilder.Entity<Products>().HasData(new Products[] {
                 new Products{ProductId=Guid.Parse("e0db1e7b-6914-49fe-ab2b-59300e8e0b52"),ProductName="HitchAdapter" ,ProductNumber="DrawTite 5504",SellingPrice=70},
                 new Products{ProductId=Guid.Parse("8f4cf9fd-9d74-415f-830e-2afa7ee8a0ae"),ProductName="BedLiner" ,ProductNumber="Rugged Liner F55U15",SellingPrice=150},
                   new Products{ProductId=Guid.Parse("b7e8168f-23dd-42a0-a374-fdb0bdc0ad6e"),ProductName="ReplacementBumper" ,ProductNumber="Sherman 036-87-1",SellingPrice=155},
                 new Products{ProductId=Guid.Parse("23367646-b737-4b2f-9380-b43f473384d1"),ProductName="SyntheticOil" ,ProductNumber="Mobil 1 5W-30",SellingPrice=25},
             });
            modelBuilder.Entity<OrderProducts>().HasData(new OrderProducts[] {
                 new OrderProducts{OrderProductId=Guid.Parse("edc90c1f-b053-418c-987f-9a4006cecb44"), OrderId=Guid.Parse("e0db1e7b-6914-49fe-ab2b-59300e8e0b52") ,ProductId=Guid.Parse("e0db1e7b-6914-49fe-ab2b-59300e8e0b52")},
                 new OrderProducts{OrderProductId=Guid.Parse("419d629f-fdb0-47e0-9a96-568220f3dba3"),OrderId=Guid.Parse("e0db1e7b-6914-49fe-ab2b-59300e8e0b52") ,ProductId=Guid.Parse("8f4cf9fd-9d74-415f-830e-2afa7ee8a0ae")},
                  new OrderProducts{OrderProductId=Guid.Parse("4ae4eed5-a00b-45a2-821c-dc128a55bf1b"), OrderId=Guid.Parse("05202731-f5e2-4430-b0df-006f5df402ae") ,ProductId=Guid.Parse("b7e8168f-23dd-42a0-a374-fdb0bdc0ad6e")},
                 new OrderProducts{OrderProductId=Guid.Parse("09f9e463-b2f6-40a4-a43b-a7da20a5dd76"),OrderId=Guid.Parse("05202731-f5e2-4430-b0df-006f5df402ae") ,ProductId=Guid.Parse("23367646-b737-4b2f-9380-b43f473384d1")},
             });
        }
    }
}
