﻿using InterviewTest.Repository.Data.Models.Orders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTest.Repository.Data.Repositories
{
    public interface IOrderRepository
    {
        void Add(IOrder newOrder);
        void Remove(IOrder removedOrder);
        List<IOrder> Get();
    }
}
