﻿using InterviewTest.Repository.Data.Models.Returns;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTest.Repository.Data.Repositories
{
    public interface IReturnRepository
    {
        void Add(IReturn newReturn);
        void Remove(IReturn removedReturn);
        List<IReturn> Get();
    }
}
