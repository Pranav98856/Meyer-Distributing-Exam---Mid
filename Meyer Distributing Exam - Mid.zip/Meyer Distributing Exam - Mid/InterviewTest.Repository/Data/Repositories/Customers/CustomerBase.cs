﻿using System;
using System.Collections.Generic;
using System.Linq;
using InterviewTest.Repository.Data.Models.Orders;
using InterviewTest.Repository.Data.Models.Returns;
using InterviewTest.Repository.Data.Repositories;

namespace InterviewTest.Customers
{
    public abstract class CustomerBase : ICustomer
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IReturnRepository _returnRepository;

        protected CustomerBase(IOrderRepository orderRepo, IReturnRepository returnRepo)
        {
            _orderRepository = orderRepo;
            _returnRepository = returnRepo;
        }

        public abstract string GetName();

        public void CreateOrder(IOrder order)
        {
            _orderRepository.Add(order);
        }

        public List<IOrder> GetOrders()
        {
            return _orderRepository.Get();
        }

        public void CreateReturn(IReturn rga)
        {
            _returnRepository.Add(rga);
        }

        public List<IReturn> GetReturns()
        {
            return _returnRepository.Get();
        }

        public float GetTotalSales()
        {
            var orderProducts = _orderRepository.Get().SelectMany(x => x.Products).ToList();

            if (orderProducts.Count > 0)
            {
                return orderProducts.Sum(x => x.Product.GetSellingPrice());
            }

            return 0;
        }

        public float GetTotalReturns()
        {
            var orderProducts = _returnRepository.Get().SelectMany(x => x.ReturnedProducts).ToList();

            if (orderProducts.Count > 0)
            {
                return orderProducts.Select(x => x.OrderProduct).Select(x => x.Product).Sum(x => x.GetSellingPrice());
            }

            return 0;
        }

        public float GetTotalProfit()
        {
            return GetTotalSales() - GetTotalReturns();
        }
    }
}
