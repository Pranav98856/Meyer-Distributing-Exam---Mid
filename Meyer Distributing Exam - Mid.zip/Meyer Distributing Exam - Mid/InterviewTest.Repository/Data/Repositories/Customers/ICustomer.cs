﻿using System.Collections.Generic;
using InterviewTest.Repository.Data.Models.Orders;
using InterviewTest.Repository.Data.Models.Returns;

namespace InterviewTest
{
    public interface ICustomer
    {
        string GetName();
        void CreateOrder(IOrder order);
        void CreateReturn(IReturn rga);
        List<IOrder> GetOrders();
        List<IReturn> GetReturns();
        float GetTotalSales();
        float GetTotalReturns();
        float GetTotalProfit();
    }
}
