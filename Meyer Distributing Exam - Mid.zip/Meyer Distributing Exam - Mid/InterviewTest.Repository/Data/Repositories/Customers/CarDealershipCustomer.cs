﻿using InterviewTest.Repository.Data.Models.Returns;
using InterviewTest.Repository.Data.Repositories;

namespace InterviewTest.Customers
{
    public class CarDealershipCustomer : CustomerBase
    {
        public CarDealershipCustomer(IOrderRepository orderRepo, IReturnRepository returnRepo)
            : base(orderRepo, returnRepo)
        {

        }

        public override string GetName()
        {
            return "Ruxer Ford Lincoln, Inc.";
        }
    }
}
