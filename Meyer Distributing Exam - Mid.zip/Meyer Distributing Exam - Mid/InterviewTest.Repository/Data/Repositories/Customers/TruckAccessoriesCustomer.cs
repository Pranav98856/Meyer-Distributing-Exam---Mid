﻿using InterviewTest.Repository.Data.Models.Returns;
using InterviewTest.Repository.Data.Repositories;

namespace InterviewTest.Customers
{
    public class TruckAccessoriesCustomer : CustomerBase
    {
        public TruckAccessoriesCustomer(IOrderRepository orderRepo, IReturnRepository returnRepo)
            : base(orderRepo, returnRepo)
        {

        }

        public override string GetName()
        {
            return "Meyer Truck Equipment";
        }
    }
}
