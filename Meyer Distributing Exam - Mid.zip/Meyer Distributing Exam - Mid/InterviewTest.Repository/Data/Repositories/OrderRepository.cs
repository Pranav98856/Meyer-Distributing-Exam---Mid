﻿using System.Collections.Generic;
using System.Linq;
using InterviewTest.Repository.Data.Models.Orders;

namespace InterviewTest.Repository.Data.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private List<IOrder> orders;
        public OrderRepository()
        {
            orders = new List<IOrder>();
        }

        public void Add(IOrder newOrder)
        {
            orders.Add(newOrder);
        }

        public void Remove(IOrder removedOrder)
        {
            orders = orders.Where(o => !string.Equals(removedOrder.OrderNumber, o.OrderNumber)).ToList();
        }

        public List<IOrder> Get()
        {
            return orders;
        }
    }
}
