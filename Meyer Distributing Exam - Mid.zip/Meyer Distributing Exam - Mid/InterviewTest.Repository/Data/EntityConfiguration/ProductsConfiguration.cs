﻿using InterviewTest.Repository.Data.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InterviewTest.Repository.Data.EntityConfiguration
{
    public class ProductsConfiguration : IEntityTypeConfiguration<Products>
    {
        public void Configure(EntityTypeBuilder<Products> products)
        {
            products.ToTable("Products");
            products.Property(product => product.ProductId).IsUnicode();
            products.Property(product => product.ProductId).ValueGeneratedOnAdd();
            products.Property(product => product.SellingPrice).HasMaxLength(20);
        }
    }
}