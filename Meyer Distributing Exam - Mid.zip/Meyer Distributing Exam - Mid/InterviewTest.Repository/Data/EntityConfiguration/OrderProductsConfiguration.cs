﻿using InterviewTest.Repository.Data.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InterviewTest.Repository.Data.EntityConfiguration
{
    public class OrderProductsConfiguration : IEntityTypeConfiguration<OrderProducts>
    {
        public void Configure(EntityTypeBuilder<OrderProducts> orders)
        {
            orders.ToTable("OrderProducts");
            orders.Property(order => order.OrderProductId).IsUnicode();
            orders.Property(order => order.OrderProductId).ValueGeneratedOnAdd();
            orders.Property(order => order.PurchasedDate).IsRequired();
            orders.HasOne(d => d.Orders).WithMany().HasForeignKey(l => l.OrderId).Metadata.DeleteBehavior = DeleteBehavior.Restrict;
            orders.Property(d => d.OrderId);
            orders.HasOne(d => d.Products).WithMany().HasForeignKey(l => l.ProductId).Metadata.DeleteBehavior = DeleteBehavior.Restrict;
            orders.Property(d => d.ProductId);
        }
    }
}
