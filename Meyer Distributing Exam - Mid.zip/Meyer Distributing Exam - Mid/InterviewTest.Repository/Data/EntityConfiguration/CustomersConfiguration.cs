﻿using InterviewTest.Repository.Data.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InterviewTest.Repository.Data.EntityConfiguration
{
    public class CustomersConfiguration : IEntityTypeConfiguration<Customer>
    {
        public void Configure(EntityTypeBuilder<Customer> customers)
        {
            customers.ToTable("Customer");
            customers.Property(customer => customer.CustomerId).IsUnicode();
            customers.Property(customer => customer.CustomerId).ValueGeneratedOnAdd();
            customers.Property(customer => customer.Name).HasMaxLength(500).IsRequired();
        }
    }
}

