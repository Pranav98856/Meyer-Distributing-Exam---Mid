﻿using InterviewTest.Repository.Data.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InterviewTest.Repository.Data.EntityConfiguration
{
    public class OrdersConfiguration : IEntityTypeConfiguration<Orders>
    {
        public void Configure(EntityTypeBuilder<Orders> orders)
        {
            orders.ToTable("Orders");
            orders.Property(order => order.OrderId).IsUnicode();
            orders.Property(order => order.OrderId).ValueGeneratedOnAdd();
            orders.Property(order => order.OrderNumber).HasMaxLength(50).IsRequired();
            orders.HasOne(d => d.Customers).WithMany().HasForeignKey(l => l.CustomerId).Metadata.DeleteBehavior = DeleteBehavior.Restrict;
            orders.Property(d => d.CustomerId);
        }
    }
}
