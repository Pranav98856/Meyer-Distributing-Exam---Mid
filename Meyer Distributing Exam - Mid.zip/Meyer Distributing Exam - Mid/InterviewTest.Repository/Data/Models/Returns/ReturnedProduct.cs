﻿using InterviewTest.Repository.Data.Models.Orders;

namespace InterviewTest.Repository.Data.Models.Returns
{
    public class ReturnedProduct
    {
        public ReturnedProduct(OrderedProduct product)
        {
            OrderProduct = product;
        }

        public OrderedProduct OrderProduct { get; set; }
    }
}
