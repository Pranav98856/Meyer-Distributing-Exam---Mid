﻿using System.Collections.Generic;
using InterviewTest.Repository.Data.Models.Orders;

namespace InterviewTest.Repository.Data.Models.Returns
{
    public interface IReturn
    {
        IOrder OriginalOrder { get; }
        List<ReturnedProduct> ReturnedProducts { get; }
        string ReturnNumber { get; }

        void AddProduct(OrderedProduct product);
    }
}