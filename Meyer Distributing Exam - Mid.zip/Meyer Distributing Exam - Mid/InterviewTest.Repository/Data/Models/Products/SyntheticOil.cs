﻿namespace InterviewTest.Repository.Data.Models.Products
{
    public class SyntheticOil : IProduct
    {
        public float GetSellingPrice()
        {
            return 25;
        }

        public string GetProductNumber()
        {
            return "Mobil 1 5W-30";
        }
    }
}
