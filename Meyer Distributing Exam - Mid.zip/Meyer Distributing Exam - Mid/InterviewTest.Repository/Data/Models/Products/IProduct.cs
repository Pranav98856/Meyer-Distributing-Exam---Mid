﻿namespace InterviewTest.Repository.Data.Models.Products
{
    public interface IProduct
    {
        string GetProductNumber();
        float GetSellingPrice();
    }
}
