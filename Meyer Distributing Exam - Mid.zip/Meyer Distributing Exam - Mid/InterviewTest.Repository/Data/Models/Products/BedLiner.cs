﻿namespace InterviewTest.Repository.Data.Models.Products
{
    public class BedLiner : IProduct
    {
        public float GetSellingPrice()
        {
            return 150;
        }

        public string GetProductNumber()
        {
            return "Rugged Liner F55U15";
        }
    }
}
