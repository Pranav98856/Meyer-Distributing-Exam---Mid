﻿using System;
using System.Collections.Generic;
using InterviewTest.Customers;

namespace InterviewTest.Repository.Data.Models.Orders
{
    public interface IOrder
    {
        ICustomer Customer { get; }
        string OrderNumber { get; }
        DateTime PurchasedDate { get; set; }
        List<OrderedProduct> Products { get; }

        void AddProduct(Products.IProduct product);
    }
}