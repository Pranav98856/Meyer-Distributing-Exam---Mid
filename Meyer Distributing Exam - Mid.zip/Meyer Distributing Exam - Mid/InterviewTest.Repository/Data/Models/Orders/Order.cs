﻿using System;
using System.Collections.Generic;
using InterviewTest.Customers;
using InterviewTest.Repository.Data.Models.Products;
using Microsoft.VisualBasic;

namespace InterviewTest.Repository.Data.Models.Orders
{
    public class Order : IOrder
    {
        public Order(string orderNumber,DateTime purchasedDate, ICustomer customer)
        {
            OrderNumber = orderNumber;
            Customer = customer;
            PurchasedDate = purchasedDate;
            Products = new List<OrderedProduct>();
        }

        public string OrderNumber { get; }

        public DateTime PurchasedDate { get; set; }

        public ICustomer Customer { get; }
        public List<OrderedProduct> Products { get; }

        public void AddProduct(IProduct product)
        {
            Products.Add(new OrderedProduct(product));
        }
    }
}
