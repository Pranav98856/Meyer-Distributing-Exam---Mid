﻿using InterviewTest.Repository.Data.Models.Products;

namespace InterviewTest.Repository.Data.Models.Orders
{
    public class OrderedProduct
    {
        public OrderedProduct(IProduct product)
        {
            Product = product;
        }

        public IProduct Product { get; set; }
    }
}
