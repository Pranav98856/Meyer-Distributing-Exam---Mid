﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace InterviewTest.Repository.Data.Entity
{
    [DataContract]
    public class Customer
    {
        [Key, Column(Order = 0), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DataMember]
        public Guid CustomerId { get; set; }

        [DataMember]
        public string Name { get; set; }
    }
}
