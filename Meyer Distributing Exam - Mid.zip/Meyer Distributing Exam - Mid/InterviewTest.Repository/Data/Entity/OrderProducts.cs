﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace InterviewTest.Repository.Data.Entity
{
    [DataContract]
    public class OrderProducts
    {
        [Key, Column(Order = 0), DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DataMember]
        public Guid OrderProductId { get; set; }

        [DataMember]
        public Guid OrderId { get; set; }

        [DataMember]
        public virtual Orders Orders { get; set; }

        [DataMember]
        public Guid ProductId { get; set; }

        [DataMember]
        public virtual Products Products { get; set; }

        [DataMember]
        public DateTime PurchasedDate { get; set; }

    }
}
